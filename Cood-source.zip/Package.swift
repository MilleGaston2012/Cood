// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "Cood",
    platforms: [.macOS(.v14)],
    products: [.executable(name: "Cood", targets: ["Cood"])],
    targets: [.executableTarget(name: "Cood")]
)
