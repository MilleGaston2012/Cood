import AppKit
import Foundation

guard CommandLine.arguments.count == 2 else { fatalError("Usage: make-icon.swift OUTPUT.png") }
let output = URL(fileURLWithPath: CommandLine.arguments[1])
let size = 1024.0
let canvas = NSImage(size: NSSize(width: size, height: size))
canvas.lockFocus()

let bounds = NSRect(x: 28, y: 28, width: 968, height: 968)
let shape = NSBezierPath(roundedRect: bounds, xRadius: 218, yRadius: 218)
NSGradient(colors: [NSColor(calibratedRed: 0.40, green: 0.33, blue: 0.97, alpha: 1),
                    NSColor(calibratedRed: 0.19, green: 0.46, blue: 0.96, alpha: 1)])!.draw(in: shape, angle: -42)

let symbolConfiguration = NSImage.SymbolConfiguration(pointSize: 430, weight: .medium)
    .applying(NSImage.SymbolConfiguration(paletteColors: [.white]))
let symbol = NSImage(systemSymbolName: "checklist", accessibilityDescription: "Cood")!
    .withSymbolConfiguration(symbolConfiguration)!
symbol.draw(in: NSRect(x: 235, y: 240, width: 554, height: 554),
            from: .zero, operation: .sourceOver, fraction: 1,
            respectFlipped: true, hints: nil)

let sparklePath = NSBezierPath()
sparklePath.move(to: NSPoint(x: 804, y: 807))
sparklePath.curve(to: NSPoint(x: 828, y: 850), controlPoint1: NSPoint(x: 804, y: 827), controlPoint2: NSPoint(x: 812, y: 842))
sparklePath.curve(to: NSPoint(x: 871, y: 874), controlPoint1: NSPoint(x: 844, y: 858), controlPoint2: NSPoint(x: 861, y: 866))
sparklePath.curve(to: NSPoint(x: 828, y: 898), controlPoint1: NSPoint(x: 861, y: 882), controlPoint2: NSPoint(x: 844, y: 890))
sparklePath.curve(to: NSPoint(x: 804, y: 941), controlPoint1: NSPoint(x: 812, y: 906), controlPoint2: NSPoint(x: 804, y: 921))
sparklePath.curve(to: NSPoint(x: 779, y: 898), controlPoint1: NSPoint(x: 804, y: 921), controlPoint2: NSPoint(x: 797, y: 906))
sparklePath.curve(to: NSPoint(x: 736, y: 874), controlPoint1: NSPoint(x: 762, y: 890), controlPoint2: NSPoint(x: 746, y: 882))
sparklePath.curve(to: NSPoint(x: 779, y: 850), controlPoint1: NSPoint(x: 746, y: 866), controlPoint2: NSPoint(x: 762, y: 858))
sparklePath.curve(to: NSPoint(x: 804, y: 807), controlPoint1: NSPoint(x: 797, y: 842), controlPoint2: NSPoint(x: 804, y: 827))
NSColor.white.withAlphaComponent(0.9).setFill()
sparklePath.fill()

canvas.unlockFocus()
guard let tiff = canvas.tiffRepresentation,
      let bitmap = NSBitmapImageRep(data: tiff),
      let png = bitmap.representation(using: .png, properties: [:]) else { fatalError("Could not encode icon") }
try png.write(to: output)
