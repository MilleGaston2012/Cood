#!/bin/sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
APP="$ROOT/Cood.app"
SDK=${SDKROOT:-$(xcrun --sdk macosx --show-sdk-path)}
WORK="${TMPDIR:-/tmp}/cood-icon-work"
ICONSET="$WORK/Cood.iconset"
rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
rm -rf "$WORK"
mkdir -p "$ICONSET"
swiftc -sdk "$SDK" -target arm64-apple-macosx14.0 \
  -module-cache-path "${TMPDIR:-/tmp}/cood-swift-module-cache" \
  "$ROOT/scripts/make-icon.swift" -o "$WORK/make-icon"
"$WORK/make-icon" "$WORK/Cood-1024.png"
for SIZE in 16 32 128 256 512; do
  DOUBLE=$((SIZE * 2))
  sips -z "$SIZE" "$SIZE" "$WORK/Cood-1024.png" --out "$ICONSET/icon_${SIZE}x${SIZE}.png" >/dev/null
  sips -z "$DOUBLE" "$DOUBLE" "$WORK/Cood-1024.png" --out "$ICONSET/icon_${SIZE}x${SIZE}@2x.png" >/dev/null
done
swiftc -sdk "$SDK" -target arm64-apple-macosx14.0 \
  -module-cache-path "${TMPDIR:-/tmp}/cood-swift-module-cache" \
  "$ROOT/scripts/make-icns.swift" -o "$WORK/make-icns"
"$WORK/make-icns" "$ICONSET" "$APP/Contents/Resources/Cood.icns"
swiftc -sdk "$SDK" -target arm64-apple-macosx14.0 \
  -module-cache-path "${TMPDIR:-/tmp}/cood-swift-module-cache" \
  -parse-as-library "$ROOT/Sources/Cood/CoodApp.swift" \
  "$ROOT/Sources/Cood/WorkspaceStore.swift" "$ROOT/Sources/Cood/MainView.swift" \
  -o "$APP/Contents/MacOS/Cood"
cat > "$APP/Contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleInfoDictionaryVersion</key><string>6.0</string>
  <key>CFBundleName</key><string>Cood</string>
  <key>CFBundleDisplayName</key><string>Cood</string>
  <key>CFBundleIdentifier</key><string>local.cood.organizer</string>
  <key>CFBundleExecutable</key><string>Cood</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleVersion</key><string>1</string>
  <key>CFBundleShortVersionString</key><string>0.1.0</string>
  <key>CFBundleIconFile</key><string>Cood</string>
  <key>CFBundleSupportedPlatforms</key><array><string>MacOSX</string></array>
  <key>LSMinimumSystemVersion</key><string>14.0</string>
  <key>NSPrincipalClass</key><string>NSApplication</string>
  <key>NSHighResolutionCapable</key><true/>
</dict>
</plist>
PLIST
printf 'APPL????' > "$APP/Contents/PkgInfo"
codesign --force --deep --sign - --identifier local.cood.organizer "$APP"
rm -rf "$WORK"
echo "Application created at $APP"
