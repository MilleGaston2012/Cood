# Cood

Cood est un espace d’organisation macOS léger et local. Les tâches, notes et raccourcis de fichiers sont enregistrés dans `~/Library/Application Support/Cood/workspace.json`.

## Fonctions

- Vue du jour, boîte de réception, tâches et notes avec éditeur enrichi (police, taille, alignement, tableaux et séparateurs)
- Section Devoirs avec matière, date de rendu, consignes et suivi des travaux terminés
- Capture rapide avec raccourci clavier `⌘N`
- Recherche locale dans les titres et contenus
- Raccourcis de fichiers et dossiers ouverts avec les apps macOS habituelles
- Suggestions simples calculées localement, sans compte, réseau ni abonnement

Les fichiers ajoutés restent à leur emplacement. Cood ne copie que leurs chemins d’accès.

## Créer l’application

La version téléchargeable cible les Mac à puce Apple (M1 et suivantes), en architecture arm64, sous macOS 14 Sonoma ou ultérieur. Elle n’est pas conçue pour les Mac Intel. Sur un Mac équipé des outils de développement Apple, lancer `./scripts/make-app.sh`, puis ouvrir `Cood.app`. Le script crée le paquet, son icône macOS et sa signature locale. Si le SDK sélectionné automatiquement ne correspond pas au compilateur Swift, définir `SDKROOT` avec le chemin d’un SDK compatible.

La version installée pour ce compte est dans `~/Applications/Cood.app` et son raccourci est dans le Dock. Les notes enrichies sont enregistrées automatiquement dans le même fichier local que les autres données; l’application sait lire les espaces de travail enregistrés par les versions précédentes.

## Limites actuelles

Cette première version n’intègre pas encore Calendrier, Rappels, Mail, Notes ou les autres applications du Mac. Les suggestions sont basées sur des règles locales et non sur un modèle d’IA.
