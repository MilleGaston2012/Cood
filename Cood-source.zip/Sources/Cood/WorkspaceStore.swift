import Foundation
import Observation
import AppKit

enum Section: String, CaseIterable, Identifiable {
    case today = "Aujourd’hui", inbox = "Boîte de réception", tasks = "Tâches", homework = "Devoirs", notes = "Notes", files = "Fichiers"
    var id: String { rawValue }
    var symbol: String {
        switch self {
        case .today: "sun.max"
        case .inbox: "tray"
        case .tasks: "checklist"
        case .homework: "book.closed"
        case .notes: "note.text"
        case .files: "folder"
        }
    }
}

struct TaskItem: Identifiable, Codable, Equatable {
    var id = UUID()
    var title: String
    var detail = ""
    var due: Date? = Calendar.current.startOfDay(for: .now)
    var completed = false
    var createdAt = Date()
}

struct NoteItem: Identifiable, Codable, Equatable {
    var id = UUID()
    var title: String
    var body = ""
    var richTextData: Data? = nil
    var updatedAt = Date()
}

struct LinkedFile: Identifiable, Codable, Equatable {
    var id = UUID()
    var url: URL
    var name: String { url.lastPathComponent }
}

struct HomeworkItem: Identifiable, Codable, Equatable {
    var id = UUID()
    var title: String
    var subject = ""
    var detail = ""
    var due = Calendar.current.date(byAdding: .day, value: 1, to: .now) ?? .now
    var completed = false
    var createdAt = Date()
}

@Observable
final class WorkspaceStore {
    var tasks: [TaskItem] = [] { didSet { save() } }
    var notes: [NoteItem] = [] { didSet { save() } }
    var files: [LinkedFile] = [] { didSet { save() } }
    var homework: [HomeworkItem] = [] { didSet { save() } }
    var selectedSection: Section = .today
    var query = ""

    private let fileURL: URL
    private var isLoading = true

    init() {
        let folder = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Cood", isDirectory: true)
        fileURL = folder.appendingPathComponent("workspace.json")
        load()
        isLoading = false
        if tasks.isEmpty && notes.isEmpty { seedWelcome() }
    }

    var openTasks: [TaskItem] { tasks.filter { !$0.completed } }
    var todayTasks: [TaskItem] {
        openTasks.filter { task in
            guard let due = task.due else { return false }
            return Calendar.current.isDateInToday(due) || due < Calendar.current.startOfDay(for: .now)
        }
    }
    var filteredTasks: [TaskItem] { query.isEmpty ? tasks : tasks.filter { searchable($0.title + " " + $0.detail) } }
    var filteredNotes: [NoteItem] { query.isEmpty ? notes : notes.filter { searchable($0.title + " " + $0.body) } }
    var filteredHomework: [HomeworkItem] {
        let matches = query.isEmpty ? homework : homework.filter { searchable($0.title + " " + $0.subject + " " + $0.detail) }
        return matches.sorted { $0.due < $1.due }
    }

    func addTask(_ title: String = "Nouvelle tâche") {
        tasks.insert(TaskItem(title: title), at: 0)
    }

    func addNote() {
        let note = NoteItem(title: "Sans titre")
        notes.insert(note, at: 0)
        selectedSection = .notes
    }

    func addHomework() {
        homework.insert(HomeworkItem(title: "Nouveau devoir"), at: 0)
    }

    func toggle(_ task: TaskItem) {
        guard let index = tasks.firstIndex(where: { $0.id == task.id }) else { return }
        tasks[index].completed.toggle()
    }

    func removeTask(_ task: TaskItem) { tasks.removeAll { $0.id == task.id } }
    func removeNote(_ note: NoteItem) { notes.removeAll { $0.id == note.id } }
    func toggleHomework(_ item: HomeworkItem) {
        guard let index = homework.firstIndex(where: { $0.id == item.id }) else { return }
        homework[index].completed.toggle()
    }
    func removeHomework(_ item: HomeworkItem) { homework.removeAll { $0.id == item.id } }

    func importFiles() {
        let panel = NSOpenPanel()
        panel.allowsMultipleSelection = true
        panel.canChooseDirectories = true
        panel.canChooseFiles = true
        panel.prompt = "Ajouter à Cood"
        guard panel.runModal() == .OK else { return }
        for url in panel.urls where !files.contains(where: { $0.url == url }) {
            files.insert(LinkedFile(url: url), at: 0)
        }
        selectedSection = .files
    }

    func reveal(_ file: LinkedFile) { NSWorkspace.shared.activateFileViewerSelecting([file.url]) }
    func open(_ file: LinkedFile) { NSWorkspace.shared.open(file.url) }

    func smartSuggestions(for task: TaskItem) -> [String] {
        let text = (task.title + " " + task.detail).lowercased()
        if text.contains("mail") || text.contains("email") { return ["Ouvrir Mail", "Bloquer 10 minutes"] }
        if text.contains("réunion") || text.contains("rendez-vous") { return ["Préparer l’ordre du jour", "Vérifier le calendrier"] }
        if text.contains("lire") || text.contains("document") { return ["Joindre le document utile", "Prévoir un créneau de lecture"] }
        return ["Ajouter une première étape", "Choisir un créneau"]
    }

    private func searchable(_ text: String) -> Bool { text.localizedCaseInsensitiveContains(query) }

    private func save() {
        guard !isLoading else { return }
        do {
            try FileManager.default.createDirectory(at: fileURL.deletingLastPathComponent(), withIntermediateDirectories: true)
            let data = try JSONEncoder().encode(WorkspaceData(tasks: tasks, notes: notes, files: files, homework: homework))
            try data.write(to: fileURL, options: .atomic)
        } catch { NSLog("Cood: impossible d’enregistrer les données locales: %@", error.localizedDescription) }
    }

    private func load() {
        guard let data = try? Data(contentsOf: fileURL),
              let decoded = try? JSONDecoder().decode(WorkspaceData.self, from: data) else { return }
        tasks = decoded.tasks
        notes = decoded.notes
        files = decoded.files
        homework = decoded.homework
    }

    private func seedWelcome() {
        notes = [NoteItem(title: "Bienvenue dans Cood", body: "Cood garde vos notes, tâches et liens de fichiers sur ce Mac. Utilisez la recherche pour retrouver une information, ou ajoutez un fichier pour l’ouvrir depuis votre espace.\n\nLes suggestions sont générées localement à partir de règles simples.")]
        tasks = [TaskItem(title: "Découvrir ma boîte de réception", detail: "Ajoutez ici les idées et tâches à trier.")]
    }
}

private struct WorkspaceData: Codable {
    var tasks: [TaskItem]
    var notes: [NoteItem]
    var files: [LinkedFile]
    var homework: [HomeworkItem]

    private enum CodingKeys: String, CodingKey { case tasks, notes, files, homework }

    init(tasks: [TaskItem], notes: [NoteItem], files: [LinkedFile], homework: [HomeworkItem]) {
        self.tasks = tasks
        self.notes = notes
        self.files = files
        self.homework = homework
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        tasks = try values.decodeIfPresent([TaskItem].self, forKey: .tasks) ?? []
        notes = try values.decodeIfPresent([NoteItem].self, forKey: .notes) ?? []
        files = try values.decodeIfPresent([LinkedFile].self, forKey: .files) ?? []
        homework = try values.decodeIfPresent([HomeworkItem].self, forKey: .homework) ?? []
    }
}
