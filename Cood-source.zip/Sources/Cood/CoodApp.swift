import SwiftUI

@main
struct CoodApp: App {
    @State private var store = WorkspaceStore()

    var body: some Scene {
        WindowGroup("Cood") {
            MainView()
                .environment(store)
                .frame(minWidth: 920, minHeight: 620)
        }
        .defaultSize(width: 1120, height: 760)
        .commands {
            CommandGroup(replacing: .newItem) {
                Button("Nouvelle tâche") { store.addTask() }.keyboardShortcut("n", modifiers: .command)
                Button("Nouvelle note") { store.addNote() }.keyboardShortcut("n", modifiers: [.command, .shift])
            }
        }
    }
}
