import AppKit
import SwiftUI

struct MainView: View {
    @Environment(WorkspaceStore.self) private var store
    @State private var showingQuickCapture = false
    @State private var captureText = ""

    var body: some View {
        NavigationSplitView {
            sidebar
        } detail: {
            VStack(spacing: 0) {
                topBar
                Divider()
                content
            }
            .background(Color(nsColor: .windowBackgroundColor))
        }
        .navigationSplitViewStyle(.balanced)
        .sheet(isPresented: $showingQuickCapture) { quickCapture }
    }

    private var sidebar: some View {
        VStack(alignment: .leading, spacing: 20) {
            HStack(spacing: 10) {
                ZStack {
                    RoundedRectangle(cornerRadius: 11).fill(Color.accentColor.gradient)
                    Image(systemName: "sparkle").font(.system(size: 18, weight: .semibold)).foregroundStyle(.white)
                }.frame(width: 34, height: 34)
                VStack(alignment: .leading, spacing: 1) {
                    Text("Cood").font(.system(size: 18, weight: .bold, design: .rounded))
                    Text("Votre espace, sur ce Mac").font(.caption2).foregroundStyle(.secondary)
                }
            }.padding(.horizontal, 4).padding(.top, 8)

            VStack(alignment: .leading, spacing: 4) {
                Text("ESPACE").font(.system(size: 10, weight: .bold)).tracking(1.2).foregroundStyle(.tertiary).padding(.horizontal, 10).padding(.bottom, 3)
                ForEach(Section.allCases) { section in
                    Button { store.selectedSection = section } label: {
                        HStack(spacing: 11) {
                            Image(systemName: section.symbol).frame(width: 17)
                            Text(section.rawValue)
                            Spacer()
                        if section == .today && !store.todayTasks.isEmpty {
                                Text("\(store.todayTasks.count)").font(.caption2).foregroundStyle(.secondary)
                            }
                            if section == .homework && !store.homework.isEmpty {
                                Text("\(store.homework.filter { !$0.completed }.count)").font(.caption2).foregroundStyle(.secondary)
                            }
                        }
                        .font(.system(size: 13, weight: store.selectedSection == section ? .semibold : .regular))
                        .foregroundStyle(store.selectedSection == section ? Color.accentColor : Color.primary.opacity(0.76))
                        .padding(.horizontal, 10).padding(.vertical, 8)
                        .background(store.selectedSection == section ? Color.accentColor.opacity(0.11) : .clear, in: RoundedRectangle(cornerRadius: 8))
                    }.buttonStyle(.plain)
                }
            }

            Spacer()
            VStack(alignment: .leading, spacing: 10) {
                HStack(spacing: 8) {
                    Image(systemName: "lock.shield").foregroundStyle(.green)
                    Text("Données conservées sur ce Mac").font(.system(size: 11, weight: .medium))
                }.foregroundStyle(.secondary)
                Text("Aucun compte. Aucune synchronisation. Aucun abonnement.")
                    .font(.system(size: 10)).foregroundStyle(.tertiary).fixedSize(horizontal: false, vertical: true)
            }
            .padding(12).frame(maxWidth: .infinity, alignment: .leading)
            .background(.quaternary.opacity(0.55), in: RoundedRectangle(cornerRadius: 12))
        }
        .padding(16)
        .frame(minWidth: 210, idealWidth: 230)
        .background(Color(nsColor: .controlBackgroundColor).opacity(0.55))
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                Button { showingQuickCapture = true } label: { Image(systemName: "plus") }
                    .help("Capture rapide")
            }
        }
    }

    private var topBar: some View {
        HStack(spacing: 14) {
            VStack(alignment: .leading, spacing: 3) {
                Text(store.selectedSection.rawValue).font(.system(size: 22, weight: .bold, design: .rounded))
                Text(subtitle).font(.system(size: 12)).foregroundStyle(.secondary)
            }
            Spacer()
            HStack(spacing: 8) {
                Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
                TextField("Rechercher dans Cood", text: Bindable(store).query)
                    .textFieldStyle(.plain)
                    .frame(width: 190)
                if !store.query.isEmpty {
                    Button { store.query = "" } label: { Image(systemName: "xmark.circle.fill").foregroundStyle(.tertiary) }.buttonStyle(.plain)
                }
            }
            .padding(9).background(Color(nsColor: .controlBackgroundColor), in: RoundedRectangle(cornerRadius: 9))
            Button { showingQuickCapture = true } label: {
                Label("Capture rapide", systemImage: "plus").font(.system(size: 12, weight: .semibold))
            }.buttonStyle(.borderedProminent).controlSize(.regular)
        }
        .padding(.horizontal, 28).padding(.vertical, 20)
    }

    private var subtitle: String {
        switch store.selectedSection {
        case .today: "Une vue claire pour avancer, sans bruit."
        case .inbox: "Notez maintenant. Organisez quand vous voulez."
        case .tasks: "Toutes vos tâches, au même endroit."
        case .homework: "Matières, échéances et travaux à rendre."
        case .notes: "Vos idées et repères enregistrés en local."
        case .files: "Des raccourcis vers vos fichiers et dossiers Mac."
        }
    }

    @ViewBuilder private var content: some View {
        switch store.selectedSection {
        case .today: TodayView()
        case .inbox: InboxView()
        case .tasks: TasksView()
        case .homework: HomeworkView()
        case .notes: NotesView()
        case .files: FilesView()
        }
    }

    private var quickCapture: some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack {
                VStack(alignment: .leading, spacing: 3) {
                    Text("Capture rapide").font(.title2.bold())
                    Text("Une idée, une tâche ou un rappel ? Déposez-le ici.").font(.callout).foregroundStyle(.secondary)
                }
                Spacer()
                Button { showingQuickCapture = false } label: { Image(systemName: "xmark.circle.fill").font(.title2).foregroundStyle(.tertiary) }.buttonStyle(.plain)
            }
            TextField("Qu’avez-vous en tête ?", text: $captureText, axis: .vertical)
                .lineLimit(3...6).textFieldStyle(.roundedBorder).font(.system(size: 16))
                .onSubmit(commitCapture)
            HStack {
                Text("Entrée pour enregistrer · Échap pour fermer").font(.caption).foregroundStyle(.tertiary)
                Spacer()
                Button("Enregistrer") { commitCapture() }.buttonStyle(.borderedProminent).disabled(captureText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }
        }
        .padding(24).frame(width: 480)
        .onExitCommand { showingQuickCapture = false }
    }

    private func commitCapture() {
        let text = captureText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return }
        store.addTask(text)
        store.selectedSection = .inbox
        captureText = ""
        showingQuickCapture = false
    }
}

private struct TodayView: View {
    @Environment(WorkspaceStore.self) private var store
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                HStack(spacing: 13) {
                    Image(systemName: "sun.max.fill").font(.title2).foregroundStyle(.orange)
                    VStack(alignment: .leading, spacing: 3) {
                        Text(Date.now.formatted(.dateTime.weekday(.wide).day().month(.wide).locale(Locale(identifier: "fr_FR"))).capitalized).font(.headline)
                        Text(store.todayTasks.isEmpty ? "Tout est calme pour le moment." : "\(store.todayTasks.count) chose\(store.todayTasks.count > 1 ? "s" : "") à faire")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer()
                    Button { store.addTask(); store.selectedSection = .tasks } label: { Label("Ajouter", systemImage: "plus") }.buttonStyle(.bordered)
                }
                .padding(18).background(.background, in: RoundedRectangle(cornerRadius: 14))

                VStack(alignment: .leading, spacing: 10) {
                    sectionHeading("À faire", detail: "Votre prochaine petite avancée")
                    if store.todayTasks.isEmpty { EmptyHint(icon: "checkmark.circle", title: "Vous êtes à jour", message: "Ajoutez une tâche quand quelque chose vous vient en tête.") }
                    ForEach(store.todayTasks) { task in TaskRow(task: task) }
                }

                VStack(alignment: .leading, spacing: 10) {
                    sectionHeading("Un coup de pouce", detail: "Suggestions simples, calculées sur ce Mac")
                    if let task = store.todayTasks.first {
                        HStack(alignment: .top, spacing: 12) {
                            Image(systemName: "sparkles").foregroundStyle(.purple).padding(.top, 2)
                            VStack(alignment: .leading, spacing: 7) {
                                Text("Pour « \(task.title) »").font(.system(size: 13, weight: .semibold))
                                ForEach(store.smartSuggestions(for: task), id: \.self) { suggestion in
                                    Label(suggestion, systemImage: "arrow.turn.down.right").font(.system(size: 12)).foregroundStyle(.secondary)
                                }
                            }
                            Spacer()
                        }.padding(15).background(.background, in: RoundedRectangle(cornerRadius: 12))
                    } else {
                        EmptyHint(icon: "sparkles", title: "L’espace pour réfléchir", message: "Quand vous ajouterez une tâche, Cood proposera une première étape.")
                    }
                }
            }
            .frame(maxWidth: 720).padding(28)
        }
    }
}

private struct InboxView: View {
    @Environment(WorkspaceStore.self) private var store
    var inbox: [TaskItem] { store.filteredTasks.filter { !$0.completed } }
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Un endroit pour tout noter").font(.title3.bold())
                        Text("La boîte de réception permet de capturer sans décider tout de suite.").font(.callout).foregroundStyle(.secondary)
                    }
                    Spacer()
                    Button { store.addTask("Nouvelle idée") } label: { Label("Ajouter une idée", systemImage: "plus") }.buttonStyle(.borderedProminent)
                }
                .padding(18).background(.background, in: RoundedRectangle(cornerRadius: 14))
                if inbox.isEmpty { EmptyHint(icon: "tray", title: "Rien à trier", message: "Les nouvelles captures apparaîtront ici.") }
                ForEach(inbox) { task in TaskRow(task: task) }
            }.frame(maxWidth: 720).padding(28)
        }
    }
}

private struct TasksView: View {
    @Environment(WorkspaceStore.self) private var store
    @State private var showCompleted = false
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    Text("\(store.openTasks.count) tâches ouvertes").font(.callout).foregroundStyle(.secondary)
                    Spacer()
                    Button { showCompleted.toggle() } label: { Text(showCompleted ? "Masquer les terminées" : "Voir les terminées") }.buttonStyle(.plain).font(.caption).foregroundStyle(.secondary)
                    Button { store.addTask() } label: { Label("Nouvelle tâche", systemImage: "plus") }.buttonStyle(.borderedProminent)
                }
                let visible = store.filteredTasks.filter { showCompleted || !$0.completed }
                if visible.isEmpty { EmptyHint(icon: "checklist", title: "Aucune tâche", message: "Ajoutez une tâche ou faites une capture rapide.") }
                ForEach(visible) { task in TaskRow(task: task) }
            }.frame(maxWidth: 720).padding(28)
        }
    }
}

private struct HomeworkView: View {
    @Environment(WorkspaceStore.self) private var store
    @State private var showCompleted = false

    private var visibleHomework: [HomeworkItem] {
        store.filteredHomework.filter { showCompleted || !$0.completed }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Tous tes devoirs au même endroit").font(.title3.bold())
                        Text("Ajoute la matière, les consignes et la date de rendu.").font(.callout).foregroundStyle(.secondary)
                    }
                    Spacer()
                    Button { showCompleted.toggle() } label: {
                        Text(showCompleted ? "Masquer les terminés" : "Voir les terminés")
                    }.buttonStyle(.plain).font(.caption).foregroundStyle(.secondary)
                    Button { store.addHomework() } label: { Label("Nouveau devoir", systemImage: "plus") }
                        .buttonStyle(.borderedProminent)
                }
                .padding(18).background(.background, in: RoundedRectangle(cornerRadius: 14))

                if visibleHomework.isEmpty {
                    EmptyHint(icon: "book.closed", title: "Aucun devoir pour le moment", message: "Ajoute un devoir pour garder en vue sa matière et son échéance.")
                }
                ForEach(visibleHomework) { item in HomeworkRow(item: item) }
            }
            .frame(maxWidth: 760).padding(28)
        }
    }
}

private struct HomeworkRow: View {
    @Environment(WorkspaceStore.self) private var store
    var item: HomeworkItem
    @State private var showingDetails = true

    private var isOverdue: Bool {
        !item.completed && item.due < Calendar.current.startOfDay(for: .now)
    }

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Button { store.toggleHomework(item) } label: {
                Image(systemName: item.completed ? "checkmark.circle.fill" : "circle")
                    .font(.system(size: 19)).foregroundStyle(item.completed ? Color.green : Color.secondary.opacity(0.6))
            }.buttonStyle(.plain).padding(.top, 2)

            VStack(alignment: .leading, spacing: 8) {
                TextField("Titre du devoir", text: titleBinding)
                    .textFieldStyle(.plain).font(.system(size: 14, weight: .semibold))
                    .strikethrough(item.completed)
                TextField("Matière (ex. histoire, maths)", text: subjectBinding)
                    .textFieldStyle(.plain).font(.system(size: 12)).foregroundStyle(.secondary)

                HStack(spacing: 6) {
                    Image(systemName: "calendar").foregroundStyle(isOverdue ? .orange : .secondary)
                    DatePicker("À rendre", selection: dueBinding, displayedComponents: .date)
                        .labelsHidden().datePickerStyle(.compact)
                    if isOverdue {
                        Text("En retard").font(.system(size: 10, weight: .medium)).foregroundStyle(.orange)
                    }
                }

                if showingDetails {
                    TextField("Consignes ou prochaines étapes…", text: detailBinding, axis: .vertical)
                        .lineLimit(2...5).textFieldStyle(.roundedBorder).font(.system(size: 12))
                }
            }

            Spacer(minLength: 8)
            Button { showingDetails.toggle() } label: { Image(systemName: "slider.horizontal.3").foregroundStyle(.tertiary) }
                .buttonStyle(.plain).help("Afficher ou masquer les consignes")
            Menu {
                Button(item.completed ? "Marquer à faire" : "Marquer comme terminé") { store.toggleHomework(item) }
                Button("Supprimer le devoir", role: .destructive) { store.removeHomework(item) }
            } label: { Image(systemName: "ellipsis").foregroundStyle(.tertiary).frame(width: 18, height: 22) }
                .menuStyle(.borderlessButton)
        }
        .padding(14).background(.background, in: RoundedRectangle(cornerRadius: 11))
    }

    private var titleBinding: Binding<String> {
        Binding(get: { current.title }, set: { value in update { $0.title = value } })
    }
    private var subjectBinding: Binding<String> {
        Binding(get: { current.subject }, set: { value in update { $0.subject = value } })
    }
    private var detailBinding: Binding<String> {
        Binding(get: { current.detail }, set: { value in update { $0.detail = value } })
    }
    private var dueBinding: Binding<Date> {
        Binding(get: { current.due }, set: { value in update { $0.due = value } })
    }
    private var current: HomeworkItem { store.homework.first(where: { $0.id == item.id }) ?? item }
    private func update(_ change: (inout HomeworkItem) -> Void) {
        guard let index = store.homework.firstIndex(where: { $0.id == item.id }) else { return }
        change(&store.homework[index])
    }
}

private struct TaskRow: View {
    @Environment(WorkspaceStore.self) private var store
    var task: TaskItem
    @State private var expanded = false
    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Button { store.toggle(task) } label: {
                Image(systemName: task.completed ? "checkmark.circle.fill" : "circle")
                    .font(.system(size: 19)).foregroundStyle(task.completed ? Color.green : Color.secondary.opacity(0.6))
            }.buttonStyle(.plain).padding(.top, 1)
            VStack(alignment: .leading, spacing: 5) {
                TextField("Nom de la tâche", text: taskTitle)
                    .textFieldStyle(.plain).font(.system(size: 13, weight: .medium))
                    .strikethrough(task.completed).foregroundStyle(task.completed ? .secondary : .primary)
                if !task.detail.isEmpty { Text(task.detail).font(.caption).foregroundStyle(.secondary).lineLimit(2) }
                if expanded {
                    TextField("Ajouter un détail…", text: taskDetail, axis: .vertical).lineLimit(2...4).textFieldStyle(.roundedBorder).font(.caption)
                    HStack(spacing: 7) {
                        Image(systemName: "sparkles").foregroundStyle(.purple)
                        Text(store.smartSuggestions(for: task).joined(separator: " · ")).font(.caption).foregroundStyle(.secondary)
                    }
                }
            }
            Spacer()
            if let due = task.due, due < Calendar.current.startOfDay(for: .now), !task.completed {
                Text("En retard").font(.system(size: 10, weight: .medium)).foregroundStyle(.orange).padding(.horizontal, 8).padding(.vertical, 4).background(.orange.opacity(0.1), in: Capsule())
            }
            Button { expanded.toggle() } label: { Image(systemName: "slider.horizontal.3").foregroundStyle(.tertiary) }.buttonStyle(.plain).help("Détails")
            Menu {
                Button(task.completed ? "Marquer à faire" : "Terminer") { store.toggle(task) }
                Button("Supprimer", role: .destructive) { store.removeTask(task) }
            } label: { Image(systemName: "ellipsis").foregroundStyle(.tertiary).frame(width: 18, height: 22) }.menuStyle(.borderlessButton)
        }
        .padding(14).background(.background, in: RoundedRectangle(cornerRadius: 11))
    }

    private var taskTitle: Binding<String> {
        Binding(get: { store.tasks.first(where: { $0.id == task.id })?.title ?? task.title }, set: { value in
            guard let index = store.tasks.firstIndex(where: { $0.id == task.id }) else { return }; store.tasks[index].title = value
        })
    }
    private var taskDetail: Binding<String> {
        Binding(get: { store.tasks.first(where: { $0.id == task.id })?.detail ?? task.detail }, set: { value in
            guard let index = store.tasks.firstIndex(where: { $0.id == task.id }) else { return }; store.tasks[index].detail = value
        })
    }
}

private struct NotesView: View {
    @Environment(WorkspaceStore.self) private var store
    @State private var selectedID: UUID?
    var body: some View {
        HStack(spacing: 0) {
            VStack(spacing: 0) {
                HStack {
                    Text("MES NOTES").font(.system(size: 10, weight: .bold)).tracking(1).foregroundStyle(.tertiary)
                    Spacer()
                    Button { store.addNote(); selectedID = store.notes.first?.id } label: { Image(systemName: "square.and.pencil") }.buttonStyle(.plain).help("Nouvelle note")
                }.padding(14)
                Divider()
                ScrollView {
                    LazyVStack(spacing: 2) {
                        ForEach(store.filteredNotes) { note in
                            Button { selectedID = note.id } label: {
                                VStack(alignment: .leading, spacing: 5) {
                                    Text(note.title.isEmpty ? "Sans titre" : note.title).font(.system(size: 12, weight: .semibold)).lineLimit(1)
                                    Text(note.body.isEmpty ? "Aucun contenu" : note.body).font(.system(size: 11)).foregroundStyle(.secondary).lineLimit(2)
                                }.frame(maxWidth: .infinity, alignment: .leading).padding(11)
                                    .background(selectedID == note.id ? Color.accentColor.opacity(0.11) : .clear, in: RoundedRectangle(cornerRadius: 8))
                            }.buttonStyle(.plain)
                        }
                    }.padding(7)
                }
            }.frame(width: 205).background(Color(nsColor: .controlBackgroundColor).opacity(0.35))
            Divider()
            if let note = store.notes.first(where: { $0.id == selectedID }) ?? store.filteredNotes.first {
                NoteEditor(note: note)
            } else {
                EmptyHint(icon: "note.text", title: "Une page blanche", message: "Créez une note pour garder une idée ou un repère.")
            }
        }.padding(18)
    }
}

private struct NoteEditor: View {
    @Environment(WorkspaceStore.self) private var store
    @Environment(\.colorScheme) private var colorScheme
    var note: NoteItem
    @State private var editorCommands = RichTextCommands()
    @State private var saveLabel = "Enregistré automatiquement"
    @State private var saveTask: Task<Void, Never>?

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text(note.updatedAt.formatted(date: .long, time: .omitted)).font(.caption).foregroundStyle(.tertiary)
                Spacer()
                Label(saveLabel, systemImage: "checkmark.circle").font(.caption).foregroundStyle(.secondary)
                Menu { Button("Supprimer la note", role: .destructive) { store.removeNote(note) } } label: { Image(systemName: "ellipsis").foregroundStyle(.secondary) }.menuStyle(.borderlessButton)
            }
            TextField("Titre de la note", text: titleBinding).textFieldStyle(.plain).font(.system(size: 24, weight: .bold, design: .rounded))
            editorToolbar
            Divider()
            RichTextEditor(text: bodyBinding, richTextData: richTextBinding, commands: editorCommands, isDarkMode: colorScheme == .dark)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .padding(.horizontal, 24).padding(.vertical, 12).frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
    }

    private var editorToolbar: some View {
        HStack(spacing: 7) {
            Menu {
                Button("Système") { editorCommands.setFontFamily(.system) }
                Button("Sérif") { editorCommands.setFontFamily(.serif) }
                Button("Monospace") { editorCommands.setFontFamily(.monospaced) }
            } label: { Label("Police", systemImage: "textformat").labelStyle(.titleAndIcon) }
                .help("Choisir la police")

            Menu {
                ForEach([11.0, 13.0, 15.0, 18.0, 24.0, 30.0], id: \.self) { size in
                    Button("\(Int(size)) pt") { editorCommands.setFontSize(size) }
                }
            } label: { Label("Taille", systemImage: "textformat.size").labelStyle(.titleAndIcon) }
                .help("Taille du texte")

            Button { editorCommands.setAlignment(.center) } label: { Image(systemName: "text.aligncenter") }
                .help("Centrer le paragraphe")
            Divider().frame(height: 18)
            Button { editorCommands.insertTable() } label: { Label("Tableau", systemImage: "tablecells") }
                .help("Insérer un tableau 2 colonnes")
            Button { editorCommands.insertSeparator() } label: { Label("Séparateur", systemImage: "line.3.horizontal") }
                .help("Insérer une ligne de séparation")
            Spacer()
        }
        .buttonStyle(.bordered).controlSize(.small)
    }

    private var titleBinding: Binding<String> {
        Binding(get: { current.title }, set: { v in update { $0.title = v }; markEditing() })
    }
    private var bodyBinding: Binding<String> {
        Binding(get: { current.body }, set: { v in update { $0.body = v; $0.updatedAt = .now }; markEditing() })
    }
    private var richTextBinding: Binding<Data?> {
        Binding(get: { current.richTextData }, set: { value in update { $0.richTextData = value; $0.updatedAt = .now }; markEditing() })
    }
    private var current: NoteItem { store.notes.first(where: { $0.id == note.id }) ?? note }
    private func update(_ change: (inout NoteItem) -> Void) {
        guard let i = store.notes.firstIndex(where: { $0.id == note.id }) else { return }; change(&store.notes[i])
    }

    private func markEditing() {
        saveLabel = "Sauvegarde…"
        saveTask?.cancel()
        saveTask = Task {
            try? await Task.sleep(for: .milliseconds(600))
            guard !Task.isCancelled else { return }
            saveLabel = "Enregistré automatiquement"
        }
    }
}

private enum NoteFontFamily { case system, serif, monospaced }

private final class RichTextCommands {
    weak var textView: NSTextView?

    func setFontFamily(_ family: NoteFontFamily) {
        guard let textView else { return }
        let current = textView.typingAttributes[.font] as? NSFont ?? textView.font ?? .systemFont(ofSize: 14)
        let newFont: NSFont
        switch family {
        case .system: newFont = .systemFont(ofSize: current.pointSize)
        case .serif: newFont = NSFont(name: "Georgia", size: current.pointSize) ?? .systemFont(ofSize: current.pointSize)
        case .monospaced: newFont = .monospacedSystemFont(ofSize: current.pointSize, weight: .regular)
        }
        apply(.font, value: newFont)
    }

    func setFontSize(_ size: CGFloat) {
        guard let textView else { return }
        let current = textView.typingAttributes[.font] as? NSFont ?? textView.font ?? .systemFont(ofSize: 14)
        apply(.font, value: NSFontManager.shared.convert(current, toSize: size))
    }

    func setAlignment(_ alignment: NSTextAlignment) {
        guard let textView else { return }
        let string = textView.string as NSString
        let selected = textView.selectedRange()
        let safeLocation = min(selected.location, string.length)
        let paragraph = string.paragraphRange(for: NSRange(location: safeLocation, length: 0))
        let style = (textView.typingAttributes[.paragraphStyle] as? NSParagraphStyle)?.mutableCopy() as? NSMutableParagraphStyle ?? NSMutableParagraphStyle()
        style.alignment = alignment
        textView.typingAttributes[.paragraphStyle] = style
        if paragraph.length > 0, paragraph.location < (textView.textStorage?.length ?? 0) {
            textView.textStorage?.addAttribute(.paragraphStyle, value: style, range: paragraph)
        }
        commitChange()
    }

    func insertSeparator() {
        guard let textView else { return }
        let separator = NSAttributedString(string: "\n────────────────────────────────\n", attributes: textView.typingAttributes)
        textView.insertText(separator, replacementRange: textView.selectedRange())
        commitChange()
    }

    func insertTable() {
        guard let textView else { return }
        let table = NSTextTable()
        table.numberOfColumns = 2
        table.collapsesBorders = true
        let content = NSMutableAttributedString()
        for row in 0..<4 {
            for column in 0..<2 {
                let block = NSTextTableBlock(table: table, startingRow: row, rowSpan: 1, startingColumn: column, columnSpan: 1)
                block.setWidth(0.6, type: .absoluteValueType, for: .border)
                block.setBorderColor(.separatorColor)
                block.setValue(50, type: .percentageValueType, for: .width)
                let paragraph = NSMutableParagraphStyle()
                paragraph.textBlocks = [block]
                paragraph.paragraphSpacing = 4
                paragraph.paragraphSpacingBefore = 4
                var attributes = textView.typingAttributes
                attributes[.paragraphStyle] = paragraph
                if row == 0 { attributes[.font] = NSFont.boldSystemFont(ofSize: 13) }
                let cell = row == 0 ? "Colonne \(column + 1)" : "\u{00a0}"
                content.append(NSAttributedString(string: cell + "\n", attributes: attributes))
            }
        }
        textView.insertText(content, replacementRange: textView.selectedRange())
        commitChange()
    }

    private func apply(_ key: NSAttributedString.Key, value: Any) {
        guard let textView else { return }
        let selected = textView.selectedRange()
        textView.typingAttributes[key] = value
        if selected.length > 0 { textView.textStorage?.addAttribute(key, value: value, range: selected) }
        commitChange()
    }

    private func commitChange() { textView?.didChangeText() }
}

private struct RichTextEditor: NSViewRepresentable {
    @Binding var text: String
    @Binding var richTextData: Data?
    var commands: RichTextCommands
    var isDarkMode: Bool

    func makeCoordinator() -> Coordinator { Coordinator(self) }

    func makeNSView(context: Context) -> NSScrollView {
        let scrollView = NSScrollView()
        scrollView.hasVerticalScroller = true
        scrollView.drawsBackground = false
        scrollView.borderType = .noBorder

        let textView = NSTextView()
        textView.delegate = context.coordinator
        textView.isRichText = true
        textView.allowsUndo = true
        textView.isAutomaticQuoteSubstitutionEnabled = true
        textView.isAutomaticDashSubstitutionEnabled = true
        textView.isAutomaticTextReplacementEnabled = true
        textView.drawsBackground = false
        textView.font = .systemFont(ofSize: 14)
        textView.textContainerInset = NSSize(width: 8, height: 10)
        textView.isVerticallyResizable = true
        textView.isHorizontallyResizable = false
        textView.autoresizingMask = [.width]
        textView.textContainer?.widthTracksTextView = true
        textView.textContainer?.containerSize = NSSize(width: 0, height: CGFloat.greatestFiniteMagnitude)

        setContent(in: textView, data: richTextData, fallback: text)
        commands.textView = textView
        context.coordinator.lastData = richTextData
        context.coordinator.updateAppearance(textView, isDarkMode: isDarkMode)
        scrollView.documentView = textView
        return scrollView
    }

    func updateNSView(_ scrollView: NSScrollView, context: Context) {
        context.coordinator.parent = self
        guard let textView = scrollView.documentView as? NSTextView else { return }
        commands.textView = textView
        context.coordinator.updateAppearance(textView, isDarkMode: isDarkMode)
        guard context.coordinator.lastData != richTextData || textView.string != text else { return }
        let selection = textView.selectedRange()
        setContent(in: textView, data: richTextData, fallback: text)
        context.coordinator.lastData = richTextData
        textView.setSelectedRange(NSRange(location: min(selection.location, textView.string.utf16.count), length: 0))
    }

    private func setContent(in textView: NSTextView, data: Data?, fallback: String) {
        let attributed: NSAttributedString
        if let data, let restored = try? NSAttributedString(
            data: data,
            options: [.documentType: NSAttributedString.DocumentType.rtf],
            documentAttributes: nil
        ) {
            attributed = restored
        } else {
            attributed = NSAttributedString(string: fallback, attributes: [.font: NSFont.systemFont(ofSize: 14)])
        }
        textView.textStorage?.setAttributedString(attributed)
    }

    final class Coordinator: NSObject, NSTextViewDelegate {
        var parent: RichTextEditor
        var lastData: Data?
        var lastDarkMode: Bool?

        init(_ parent: RichTextEditor) { self.parent = parent }

        func textDidChange(_ notification: Notification) {
            guard let textView = notification.object as? NSTextView else { return }
            storeContent(from: textView)
        }

        func updateAppearance(_ textView: NSTextView, isDarkMode: Bool) {
            guard lastDarkMode != isDarkMode else { return }
            lastDarkMode = isDarkMode
            let color = isDarkMode ? NSColor.white : NSColor.labelColor
            textView.typingAttributes[.foregroundColor] = color
            if let storage = textView.textStorage, storage.length > 0 {
                storage.addAttribute(.foregroundColor, value: color, range: NSRange(location: 0, length: storage.length))
                storeContent(from: textView)
            }
        }

        private func storeContent(from textView: NSTextView) {
            let attributed = textView.attributedString()
            let range = NSRange(location: 0, length: attributed.length)
            let data = try? attributed.data(from: range, documentAttributes: [.documentType: NSAttributedString.DocumentType.rtf])
            lastData = data
            parent.richTextData = data
            parent.text = attributed.string
        }
    }
}

private struct FilesView: View {
    @Environment(WorkspaceStore.self) private var store
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Vos fichiers, à portée de main").font(.title3.bold())
                    Text("Cood garde des raccourcis. Les fichiers restent dans leur dossier d’origine.").font(.callout).foregroundStyle(.secondary)
                }
                Spacer()
                Button { store.importFiles() } label: { Label("Ajouter des fichiers", systemImage: "folder.badge.plus") }.buttonStyle(.borderedProminent)
            }.padding(18).background(.background, in: RoundedRectangle(cornerRadius: 14))
            if store.files.isEmpty {
                EmptyHint(icon: "folder", title: "Aucun fichier ajouté", message: "Choisissez des fichiers ou dossiers pour créer des raccourcis locaux.")
            }
            List {
                ForEach(store.files) { file in
                    HStack(spacing: 12) {
                        Image(systemName: file.url.hasDirectoryPath ? "folder.fill" : "doc.fill").font(.title3).foregroundStyle(.blue)
                        VStack(alignment: .leading, spacing: 3) {
                            Text(file.name).font(.system(size: 13, weight: .medium))
                            Text(file.url.deletingLastPathComponent().path).font(.caption2).foregroundStyle(.tertiary).lineLimit(1)
                        }
                        Spacer()
                        Button { store.open(file) } label: { Image(systemName: "arrow.up.right.square") }.buttonStyle(.plain).help("Ouvrir")
                        Button { store.reveal(file) } label: { Image(systemName: "magnifyingglass") }.buttonStyle(.plain).help("Afficher dans le Finder")
                    }.padding(.vertical, 3).contextMenu { Button("Ouvrir") { store.open(file) }; Button("Afficher dans le Finder") { store.reveal(file) }; Button("Retirer de Cood", role: .destructive) { store.files.removeAll { $0.id == file.id } } }
                }
                .onDelete { offsets in store.files.remove(atOffsets: offsets) }
            }.listStyle(.inset).scrollContentBackground(.hidden)
        }.frame(maxWidth: 760, maxHeight: .infinity, alignment: .topLeading).padding(28)
    }
}

private struct EmptyHint: View {
    var icon: String
    var title: String
    var message: String
    var body: some View {
        VStack(spacing: 8) {
            Image(systemName: icon).font(.system(size: 24)).foregroundStyle(.tertiary)
            Text(title).font(.system(size: 13, weight: .semibold))
            Text(message).font(.system(size: 12)).foregroundStyle(.secondary).multilineTextAlignment(.center).frame(maxWidth: 360)
        }.frame(maxWidth: .infinity).padding(28).background(.background, in: RoundedRectangle(cornerRadius: 12))
    }
}

private func sectionHeading(_ title: String, detail: String) -> some View {
    VStack(alignment: .leading, spacing: 3) {
        Text(title).font(.system(size: 15, weight: .bold, design: .rounded))
        Text(detail).font(.system(size: 11)).foregroundStyle(.secondary)
    }.padding(.bottom, 2)
}
